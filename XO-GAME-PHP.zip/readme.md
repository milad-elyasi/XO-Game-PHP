This is A php script that contains a multi player xo game (tic tac toe) with complete log and reply the moves with ajax.
it has a database using mysqli.
the file has been included.
the config setting is on : includes/config.php 